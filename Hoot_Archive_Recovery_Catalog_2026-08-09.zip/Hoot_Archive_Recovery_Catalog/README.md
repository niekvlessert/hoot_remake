# Hoot Archive Recovery Catalog

This bundle reconstructs a static catalog for the Hoot Archive at
`https://snesmusic.org/hoot/v2/`. The dynamic PHP/database pages stopped
rendering, while the official pack storage and metadata downloads remained
available.

## Contents

- `hoot_archive_catalog.html` — standalone searchable browser with original download links.
- `hoot_archive_catalog.json` — complete machine-readable catalog, including contained files and CRC32 values.
- `hoot_archive_catalog.csv` — flat pack-level export.
- `hoot_archive_catalog.sqlite3` — normalized SQLite database (`packs`, `files`, `alternate_titles`, `metadata`).
- `verify_hoot_archive.py` — optional low-impact link verifier.
- `verification_report.json` — generation-time verification sample.
- `build_hoot_catalog.py` — reproducible catalog generator.

## Catalog summary

- Packs: 2,404
- Systems: 14
- XML metadata matches: 2,385
- Files described by manifests: 57,024

Arcade ROM entries are intentionally excluded because the Hoot site did not
host those ROM sets. No game music archives are included in this bundle.

## Usage

Open `hoot_archive_catalog.html` in a browser. It does not need a web server.

To verify a considerate sample of 25 original links:

```sh
python3 verify_hoot_archive.py
```

To check a larger sample:

```sh
python3 verify_hoot_archive.py --sample 100
```

Avoid repeatedly checking every link: this is an old community server.

## Generation-time link check

A deterministic sample of 20 reconstructed URLs was tested on 9 August 2026.
All 20 returned a valid ZIP signature. This confirms the URL reconstruction
for the sample; it does not claim that every one of the 2,404 links is present.

## Sources

- `https://snesmusic.org/hoot/hoot_datafile.zip`
- `https://snesmusic.org/hoot/hoot-ini.zip`

Generated: 2026-08-09T19:32:49+00:00
