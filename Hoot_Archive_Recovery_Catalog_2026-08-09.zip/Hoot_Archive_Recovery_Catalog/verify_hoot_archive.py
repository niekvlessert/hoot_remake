#!/usr/bin/env python3
"""Verify reconstructed Hoot Archive links without downloading full packs."""
import argparse, concurrent.futures, json, random, urllib.request
from pathlib import Path

def check(pack):
    request=urllib.request.Request(pack["url"],headers={"Range":"bytes=0-3","User-Agent":"Hoot-Archive-Link-Verifier/1.0"})
    try:
        with urllib.request.urlopen(request,timeout=30) as response:
            signature=response.read(4)
            ok=response.status in (200,206) and signature==b"PK\x03\x04"
            return {"archive":pack["archive"],"system":pack["system"],"url":pack["url"],"status":response.status,"zip":ok}
    except Exception as exc:
        return {"archive":pack["archive"],"system":pack["system"],"url":pack["url"],"status":getattr(exc,"code",None),"zip":False,"error":str(exc)}

p=argparse.ArgumentParser()
p.add_argument("--catalog",default="hoot_archive_catalog.json")
g=p.add_mutually_exclusive_group();g.add_argument("--all",action="store_true",help="Check all links; be considerate of the old server")
g.add_argument("--sample",type=int,default=25,help="Deterministic sample size (default: 25)")
p.add_argument("--workers",type=int,default=4)
p.add_argument("--output",default="verification_report.json")
a=p.parse_args()
packs=json.loads(Path(a.catalog).read_text(encoding="utf-8"))["packs"]
if not a.all:
    random.Random(20080905).shuffle(packs);packs=packs[:max(1,min(a.sample,len(packs)))]
with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,min(a.workers,8))) as pool:
    results=list(pool.map(check,packs))
Path(a.output).write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
good=sum(item["zip"] for item in results)
print(f"Verified {good}/{len(results)} ZIP links; report: {a.output}")
