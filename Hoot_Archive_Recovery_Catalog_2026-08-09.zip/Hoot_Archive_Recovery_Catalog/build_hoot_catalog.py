#!/usr/bin/env python3
"""Build a static recovery catalog for the snesmusic.org Hoot Archive.

The original v2 PHP catalog currently stops rendering when database-backed
pages are requested.  The official Hoot datafile and INI archives are still
available and contain enough information to reconstruct a useful catalog.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import re
import shutil
import sqlite3
import urllib.parse
import urllib.request
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


DATAFILE_URL = "https://snesmusic.org/hoot/hoot_datafile.zip"
INI_URL = "https://snesmusic.org/hoot/hoot-ini.zip"
ARCHIVE_BASE_URL = "https://snesmusic.org/hoot/sets"

SYSTEMS = {
    "Fujitsu FM Towns ClrMame.dat": ("fmtowns", "Fujitsu FM Towns", "other"),
    "Fujitsu FM-7 ClrMame.dat": ("fm7", "Fujitsu FM-7", "other"),
    "IBM PC-AT ClrMame.dat": ("ibmpc", "IBM PC-AT", "other"),
    "Microsoft MSX ClrMame.dat": ("msx", "Microsoft MSX", "msx"),
    "NEC PC-8801 ClrMame.dat": ("pc88", "NEC PC-8801", "pc88"),
    "NEC PC-88VA ClrMame.dat": ("pc88va", "NEC PC-88VA", "pc88"),
    "NEC PC-9801 ClrMame.dat": ("pc98", "NEC PC-9801", "pc98"),
    "NEC PC-9821 ClrMame.dat": ("pc9821", "NEC PC-9821", "pc98"),
    "Nintendo Gameboy ClrMame.dat": ("gb", "Nintendo Game Boy", "other"),
    "Nintendo NES ClrMame.dat": ("nes", "Nintendo NES", "other"),
    "Nintendo SNES ClrMame.dat": ("snes", "Nintendo SNES", "other"),
    "Sega Mega Drive ClrMame.dat": ("megadrive", "Sega Mega Drive", "other"),
    "Sharp X1 ClrMame.dat": ("x1", "Sharp X1", "x1"),
    "Sharp X68000 ClrMame.dat": ("x68k", "Sharp X68000", "x68k"),
}

COMPANY_OVERRIDES = {
    "13cm": "13cm",
    "4x9": "4x9",
    "adk": "ADK",
    "ascii": "ASCII",
    "atlus": "Atlus",
    "bps": "BPS",
    "c's_ware": "C's Ware",
    "c-lab": "C-Lab",
    "dataeast": "Data East",
    "datawest": "Data West",
    "dbsoft": "dB-SOFT",
    "dempa": "Dempa",
    "do": "D.O.",
    "enix": "Enix",
    "falcom": "Falcom",
    "fmc": "FMC",
    "gamearts": "Game Arts",
    "hudson": "Hudson Soft",
    "irem": "Irem",
    "koei": "Koei",
    "kogado": "Kogado",
    "konami": "Konami",
    "microcabin": "Micro Cabin",
    "namco": "Namco",
    "nec": "NEC",
    "nihon_telenet": "Nihon Telenet",
    "nintendo": "Nintendo",
    "sacom": "System Sacom",
    "sega": "Sega",
    "square": "Square",
    "systemsoft": "SystemSoft",
    "t&e": "T&E Soft",
    "taito": "Taito",
    "technosoft": "Technosoft",
    "telenet_japan": "Telenet Japan",
    "wolfteam": "Wolfteam",
}


def fetch(url: str) -> tuple[bytes, dict[str, str]]:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Hoot-Archive-Recovery-Catalog/1.0"},
    )
    with urllib.request.urlopen(request, timeout=90) as response:
        return response.read(), {k.lower(): v for k, v in response.headers.items()}


def decode_text(raw: bytes) -> str:
    for encoding in ("cp932", "shift_jis", "utf-8"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            pass
    return raw.decode("cp932", errors="replace")


def parse_dat_games(text: str) -> list[dict]:
    games: list[dict] = []
    block: list[str] = []
    depth = 0
    active = False

    for line in text.splitlines():
        stripped = line.strip()
        if not active and re.fullmatch(r"game\s*\(", stripped, re.I):
            active = True
            block = [line]
            depth = 1
            continue
        if not active:
            continue

        block.append(line)
        depth += line.count("(") - line.count(")")
        if depth > 0:
            continue

        body = "\n".join(block)
        name_match = re.search(r"(?mi)^\s*name\s+(?:\"([^\"]+)\"|(\S+))\s*$", body)
        if name_match:
            archive = (name_match.group(1) or name_match.group(2)).strip()
            description_match = re.search(
                r"(?mi)^\s*description\s+(?:\"([^\"]*)\"|(\S+))\s*$", body
            )
            files = []
            for match in re.finditer(
                r"(?mi)^\s*rom\s*\(\s*name\s+(?:\"([^\"]+)\"|(\S+))"
                r"\s+size\s+(\d+)\s+crc\s+([0-9a-f]+)\s*\)\s*$",
                body,
            ):
                files.append(
                    {
                        "name": match.group(1) or match.group(2),
                        "size": int(match.group(3)),
                        "crc32": match.group(4).lower(),
                    }
                )
            games.append(
                {
                    "archive": archive,
                    "description": (
                        (description_match.group(1) or description_match.group(2)).strip()
                        if description_match
                        else archive
                    ),
                    "files": files,
                }
            )

        active = False
        block = []
        depth = 0

    return games


def xml_text(fragment: str, tag: str) -> tuple[str, dict[str, str]] | None:
    match = re.search(
        rf"<{tag}\b([^>]*)>(.*?)</{tag}>", fragment, flags=re.I | re.S
    )
    if not match:
        return None
    attrs = {
        key.lower(): html.unescape(value)
        for key, _, value in re.findall(r"([\w:-]+)\s*=\s*(['\"])(.*?)\2", match.group(1))
    }
    value = re.sub(r"<[^>]+>", "", match.group(2))
    return html.unescape(value).strip(), attrs


def company_display(slug: str) -> str:
    if slug in COMPANY_OVERRIDES:
        return COMPANY_OVERRIDES[slug]
    words = slug.replace("_", " ").replace("-", " ").split()
    return " ".join(word.upper() if len(word) <= 3 else word.title() for word in words)


def clean_title(value: str) -> str:
    value = re.sub(r"^\s*\[[^\]]+\]\s*", "", value)
    return re.sub(r"\s+", " ", value).strip()


def parse_ini_metadata(ini_zip: zipfile.ZipFile) -> dict[str, list[dict]]:
    metadata: dict[str, list[dict]] = defaultdict(list)
    for member in sorted(ini_zip.namelist()):
        if not member.lower().startswith("xml/") or not member.lower().endswith(".xml"):
            continue
        slug = Path(member).stem.lower()
        if slug in {"drivers", "hoot"}:
            continue
        text = decode_text(ini_zip.read(member))
        for match in re.finditer(r"<game\b[^>]*>(.*?)</game>", text, flags=re.I | re.S):
            fragment = match.group(1)
            romlist = re.search(r"<romlist\b([^>]*)>", fragment, flags=re.I | re.S)
            if not romlist:
                continue
            archive_match = re.search(
                r"\barchive\s*=\s*(['\"])(.*?)\1", romlist.group(1), flags=re.I | re.S
            )
            if not archive_match:
                continue
            archive = html.unescape(archive_match.group(2)).strip()
            name = xml_text(fragment, "name")
            driver = xml_text(fragment, "driver")
            alias = xml_text(fragment, "driveralias")
            record = {
                "title": clean_title(name[0]) if name else archive,
                "original_name": name[0] if name else archive,
                "company_id": slug,
                "company": company_display(slug),
                "driver": driver[0] if driver else "",
                "driver_type": driver[1].get("type", "") if driver else "",
                "driver_alias": alias[0] if alias else "",
                "driver_alias_type": alias[1].get("type", "") if alias else "",
                "source_xml": member,
            }
            key = archive.casefold()
            if record not in metadata[key]:
                metadata[key].append(record)
    return metadata


def choose_metadata(records: list[dict], system_label: str) -> dict:
    if not records:
        return {}
    system_tokens = {
        "Fujitsu FM Towns": ("fm towns", "fmtowns"),
        "Fujitsu FM-7": ("fm-7", "fm7", "fm-77"),
        "IBM PC-AT": ("ibm", "pc-at", "pc"),
        "Microsoft MSX": ("msx",),
        "NEC PC-8801": ("pc-88", "pc88", "pc-8801"),
        "NEC PC-88VA": ("pc-88va", "pc88va"),
        "NEC PC-9801": ("pc-98", "pc98", "pc-9801"),
        "NEC PC-9821": ("pc-9821", "pc9821"),
        "Nintendo Game Boy": ("game boy", "gb"),
        "Nintendo NES": ("nes",),
        "Nintendo SNES": ("snes",),
        "Sega Mega Drive": ("mega drive", "megadrive"),
        "Sharp X1": ("x1",),
        "Sharp X68000": ("x68", "x68000"),
    }.get(system_label, ())
    for record in records:
        haystack = " ".join(
            [record["original_name"], record["driver"], record["driver_type"], record["driver_alias_type"]]
        ).casefold()
        if any(token in haystack for token in system_tokens):
            return record
    return records[0]


def build_catalog(data_bytes: bytes, ini_bytes: bytes) -> tuple[list[dict], dict]:
    data_zip = zipfile.ZipFile(io.BytesIO(data_bytes))
    ini_zip = zipfile.ZipFile(io.BytesIO(ini_bytes))
    metadata = parse_ini_metadata(ini_zip)
    packs: list[dict] = []

    for manifest_name, (system_id, system, directory) in SYSTEMS.items():
        manifest = decode_text(data_zip.read(manifest_name))
        for game in parse_dat_games(manifest):
            records = metadata.get(game["archive"].casefold(), [])
            selected = choose_metadata(records, system)
            filename = game["archive"] + ".zip"
            url = "/".join(
                [ARCHIVE_BASE_URL, directory, urllib.parse.quote(filename, safe="._-()[]")]
            )
            names = []
            for record in records:
                if record["title"] and record["title"] not in names:
                    names.append(record["title"])
            title = selected.get("title") or game["description"] or game["archive"]
            packs.append(
                {
                    "archive": game["archive"],
                    "filename": filename,
                    "title": title,
                    "alternate_titles": [name for name in names if name != title],
                    "company_id": selected.get("company_id", ""),
                    "company": selected.get("company", "Unknown"),
                    "system_id": system_id,
                    "system": system,
                    "directory": directory,
                    "driver": selected.get("driver", ""),
                    "driver_type": selected.get("driver_type", ""),
                    "driver_alias": selected.get("driver_alias", ""),
                    "driver_alias_type": selected.get("driver_alias_type", ""),
                    "url": url,
                    "file_count": len(game["files"]),
                    "uncompressed_bytes": sum(item["size"] for item in game["files"]),
                    "files": game["files"],
                    "metadata_matched": bool(selected),
                    "source_manifest": manifest_name,
                    "source_xml": selected.get("source_xml", ""),
                }
            )

    packs.sort(key=lambda item: (item["system"].casefold(), item["title"].casefold(), item["archive"]))
    stats = {
        "pack_count": len(packs),
        "metadata_matched": sum(1 for pack in packs if pack["metadata_matched"]),
        "system_count": len({pack["system_id"] for pack in packs}),
        "company_count": len({pack["company_id"] for pack in packs if pack["company_id"]}),
        "file_count": sum(pack["file_count"] for pack in packs),
        "uncompressed_bytes": sum(pack["uncompressed_bytes"] for pack in packs),
        "by_system": {
            system: sum(1 for pack in packs if pack["system"] == system)
            for system in sorted({pack["system"] for pack in packs})
        },
    }
    return packs, stats


def write_json(path: Path, catalog: dict) -> None:
    path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path: Path, packs: list[dict]) -> None:
    fields = [
        "system",
        "title",
        "alternate_titles",
        "company",
        "archive",
        "filename",
        "driver",
        "driver_type",
        "file_count",
        "uncompressed_bytes",
        "metadata_matched",
        "url",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for pack in packs:
            row = {field: pack.get(field, "") for field in fields}
            row["alternate_titles"] = " | ".join(pack["alternate_titles"])
            writer.writerow(row)


def write_sqlite(path: Path, catalog: dict) -> None:
    if path.exists():
        path.unlink()
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        PRAGMA foreign_keys=ON;
        CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE packs (
          id INTEGER PRIMARY KEY,
          archive TEXT NOT NULL UNIQUE,
          filename TEXT NOT NULL,
          title TEXT NOT NULL,
          company_id TEXT NOT NULL,
          company TEXT NOT NULL,
          system_id TEXT NOT NULL,
          system TEXT NOT NULL,
          directory TEXT NOT NULL,
          driver TEXT NOT NULL,
          driver_type TEXT NOT NULL,
          driver_alias TEXT NOT NULL,
          driver_alias_type TEXT NOT NULL,
          url TEXT NOT NULL,
          file_count INTEGER NOT NULL,
          uncompressed_bytes INTEGER NOT NULL,
          metadata_matched INTEGER NOT NULL,
          source_manifest TEXT NOT NULL,
          source_xml TEXT NOT NULL
        );
        CREATE TABLE alternate_titles (
          pack_id INTEGER NOT NULL REFERENCES packs(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          PRIMARY KEY (pack_id, title)
        );
        CREATE TABLE files (
          id INTEGER PRIMARY KEY,
          pack_id INTEGER NOT NULL REFERENCES packs(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          size INTEGER NOT NULL,
          crc32 TEXT NOT NULL
        );
        CREATE INDEX packs_title_idx ON packs(title COLLATE NOCASE);
        CREATE INDEX packs_company_idx ON packs(company COLLATE NOCASE);
        CREATE INDEX packs_system_idx ON packs(system_id);
        CREATE INDEX packs_driver_idx ON packs(driver COLLATE NOCASE);
        CREATE INDEX files_pack_idx ON files(pack_id);
        """
    )
    for key, value in {
        "schema_version": "1",
        "generated_at": catalog["generated_at"],
        "datafile_url": catalog["sources"]["datafile"]["url"],
        "datafile_sha256": catalog["sources"]["datafile"]["sha256"],
        "ini_url": catalog["sources"]["ini"]["url"],
        "ini_sha256": catalog["sources"]["ini"]["sha256"],
    }.items():
        connection.execute("INSERT INTO metadata(key,value) VALUES (?,?)", (key, value))

    for pack in catalog["packs"]:
        cursor = connection.execute(
            """
            INSERT INTO packs(
              archive,filename,title,company_id,company,system_id,system,directory,
              driver,driver_type,driver_alias,driver_alias_type,url,file_count,
              uncompressed_bytes,metadata_matched,source_manifest,source_xml
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                pack["archive"], pack["filename"], pack["title"], pack["company_id"],
                pack["company"], pack["system_id"], pack["system"], pack["directory"],
                pack["driver"], pack["driver_type"], pack["driver_alias"],
                pack["driver_alias_type"], pack["url"], pack["file_count"],
                pack["uncompressed_bytes"], int(pack["metadata_matched"]),
                pack["source_manifest"], pack["source_xml"],
            ),
        )
        pack_id = cursor.lastrowid
        connection.executemany(
            "INSERT INTO alternate_titles(pack_id,title) VALUES (?,?)",
            [(pack_id, title) for title in pack["alternate_titles"]],
        )
        connection.executemany(
            "INSERT INTO files(pack_id,name,size,crc32) VALUES (?,?,?,?)",
            [(pack_id, item["name"], item["size"], item["crc32"]) for item in pack["files"]],
        )
    connection.commit()
    connection.execute("VACUUM")
    connection.close()


def compact_pack(pack: dict) -> dict:
    return {
        "a": pack["archive"],
        "t": pack["title"],
        "x": pack["alternate_titles"],
        "c": pack["company"],
        "s": pack["system"],
        "d": pack["driver"],
        "y": pack["driver_type"],
        "n": pack["file_count"],
        "b": pack["uncompressed_bytes"],
        "m": pack["metadata_matched"],
        "u": pack["url"],
    }


HTML_TEMPLATE = r'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Hoot Archive Recovery Catalog</title>
  <style>
    :root{color-scheme:dark;--bg:#0a0d12;--panel:#121824;--line:#253046;--text:#edf2fb;--muted:#93a4bf;--cyan:#60d9e8;--amber:#ffc857;--good:#7ee787}
    *{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% -10%,#153044 0,transparent 35%),var(--bg);color:var(--text);font:14px/1.45 system-ui,-apple-system,Segoe UI,sans-serif}
    main{max-width:1520px;margin:auto;padding:28px}h1{font-size:clamp(26px,4vw,48px);margin:0;letter-spacing:-.04em}h1 span{color:var(--cyan)}
    .sub{color:var(--muted);max-width:900px;margin:8px 0 22px}.cards{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:10px;margin-bottom:16px}
    .card,.toolbar,.tablebox{background:rgba(18,24,36,.92);border:1px solid var(--line);border-radius:13px}.card{padding:14px}.card b{display:block;font-size:25px;color:var(--amber)}.card span{color:var(--muted)}
    .toolbar{display:grid;grid-template-columns:minmax(260px,2fr) repeat(3,minmax(150px,1fr)) auto;gap:10px;padding:12px;margin-bottom:12px;position:sticky;top:8px;z-index:5;backdrop-filter:blur(12px)}
    input,select,button{width:100%;border:1px solid var(--line);border-radius:8px;background:#0d131e;color:var(--text);padding:10px 11px;font:inherit}button{width:auto;cursor:pointer}button:hover,a.download:hover{border-color:var(--cyan)}
    .tablebox{overflow:hidden}.summary{display:flex;justify-content:space-between;gap:12px;padding:12px 15px;color:var(--muted);border-bottom:1px solid var(--line)}
    .scroller{overflow:auto;max-height:67vh}table{width:100%;border-collapse:collapse;min-width:1100px}th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #1e2738;vertical-align:top}th{position:sticky;top:0;background:#151d2a;color:#afbdd1;z-index:2;cursor:pointer;white-space:nowrap}tr:hover td{background:#111b29}
    td.title{font-weight:650}.archive,code{font:12px ui-monospace,SFMono-Regular,Menlo,monospace;color:#b9c5d8}.muted{color:var(--muted)}.unknown{color:#ff9b9b}
    a.download{display:inline-block;color:var(--cyan);text-decoration:none;border:1px solid var(--line);border-radius:7px;padding:5px 9px;white-space:nowrap}
    .pager{display:flex;align-items:center;justify-content:flex-end;gap:8px;padding:11px 13px}.pager button{width:auto}.note{margin-top:12px;color:var(--muted)}
    @media(max-width:950px){main{padding:18px}.cards{grid-template-columns:repeat(2,1fr)}.toolbar{grid-template-columns:1fr 1fr;position:static}.toolbar input{grid-column:1/-1}}
  </style>
</head>
<body><main>
  <h1>Hoot Archive <span>Recovery Catalog</span></h1>
  <p class="sub">A static catalog reconstructed from the official Hoot INI and ClrMamePro datafiles. Download buttons point to the original snesmusic.org archive; the music packs are not embedded here.</p>
  <section class="cards">
    <div class="card"><b id="total"></b><span>non-arcade packs</span></div>
    <div class="card"><b id="systems"></b><span>systems</span></div>
    <div class="card"><b id="matched"></b><span>packs matched to XML metadata</span></div>
    <div class="card"><b id="files"></b><span>files described by manifests</span></div>
  </section>
  <section class="toolbar">
    <input id="q" type="search" placeholder="Search title, archive, company or driver…" autofocus>
    <select id="system"><option value="">All systems</option></select>
    <select id="company"><option value="">All companies</option></select>
    <select id="driver"><option value="">All drivers</option></select>
    <button id="export">Export filtered CSV</button>
  </section>
  <section class="tablebox">
    <div class="summary"><span id="result"></span><span id="sortlabel"></span></div>
    <div class="scroller"><table><thead><tr>
      <th data-sort="s">System</th><th data-sort="t">Game</th><th data-sort="c">Company</th><th data-sort="a">Archive</th><th data-sort="d">Driver</th><th data-sort="n">Files</th><th data-sort="b">Size</th><th>Original file</th>
    </tr></thead><tbody id="rows"></tbody></table></div>
    <div class="pager"><button id="prev">Previous</button><span id="page"></span><button id="next">Next</button></div>
  </section>
  <p class="note">Metadata source date: 5 September 2008. Links are reconstructed from the official directory layout and are not all tested during generation.</p>
</main><script>
const PACKS=__PACKS__;
const STATS=__STATS__;
const PAGE_SIZE=100;
let page=1,sortKey='t',sortDir=1,filtered=[];
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const size=n=>{if(!n)return '0 B';const u=['B','KiB','MiB','GiB'];const i=Math.min(Math.floor(Math.log(n)/Math.log(1024)),3);return `${(n/1024**i).toFixed(i?1:0)} ${u[i]}`};
function options(id,values){for(const v of [...new Set(values.filter(Boolean))].sort((a,b)=>a.localeCompare(b)))$(id).insertAdjacentHTML('beforeend',`<option>${esc(v)}</option>`)}
function apply(){const q=$('q').value.trim().toLocaleLowerCase(),sys=$('system').value,company=$('company').value,driver=$('driver').value;
 filtered=PACKS.filter(p=>(!sys||p.s===sys)&&(!company||p.c===company)&&(!driver||p.d===driver)&&(!q||[p.t,p.a,p.c,p.s,p.d,p.y,...p.x].join('\n').toLocaleLowerCase().includes(q)));
 filtered.sort((a,b)=>{const av=a[sortKey],bv=b[sortKey];return (typeof av==='number'?av-bv:String(av).localeCompare(String(bv),undefined,{numeric:true,sensitivity:'base'}))*sortDir});
 page=1;render()}
function render(){const pages=Math.max(1,Math.ceil(filtered.length/PAGE_SIZE));page=Math.min(page,pages);const start=(page-1)*PAGE_SIZE;
 $('rows').innerHTML=filtered.slice(start,start+PAGE_SIZE).map(p=>`<tr><td>${esc(p.s)}</td><td class="title">${esc(p.t)}${p.x.length?`<div class="muted">${esc(p.x.join(' · '))}</div>`:''}</td><td class="${p.m?'':'unknown'}">${esc(p.c)}</td><td class="archive">${esc(p.a)}.zip</td><td>${esc(p.d||'—')}<div class="muted">${esc(p.y)}</div></td><td>${p.n.toLocaleString()}</td><td>${size(p.b)}</td><td><a class="download" href="${esc(p.u)}" target="_blank" rel="noreferrer">Download ZIP</a></td></tr>`).join('');
 $('result').textContent=`${filtered.length.toLocaleString()} matching packs`; $('page').textContent=`Page ${page} of ${pages}`;$('prev').disabled=page<=1;$('next').disabled=page>=pages;$('sortlabel').textContent=`Sorted by ${sortKey} ${sortDir>0?'↑':'↓'}`}
function csv(){const fields=['System','Title','Company','Archive','Driver','Files','Uncompressed bytes','URL'];const quote=v=>'"'+String(v??'').replaceAll('"','""')+'"';const body=[fields,...filtered.map(p=>[p.s,p.t,p.c,p.a+'.zip',p.d,p.n,p.b,p.u])].map(r=>r.map(quote).join(',')).join('\r\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([body],{type:'text/csv;charset=utf-8'}));a.download='hoot_archive_filtered.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
$('total').textContent=STATS.pack_count.toLocaleString();$('systems').textContent=STATS.system_count.toLocaleString();$('matched').textContent=STATS.metadata_matched.toLocaleString();$('files').textContent=STATS.file_count.toLocaleString();
options('system',PACKS.map(p=>p.s));options('company',PACKS.map(p=>p.c));options('driver',PACKS.map(p=>p.d));
for(const id of ['q','system','company','driver'])$(id).addEventListener(id==='q'?'input':'change',apply);$('export').onclick=csv;$('prev').onclick=()=>{page--;render()};$('next').onclick=()=>{page++;render()};
document.querySelectorAll('th[data-sort]').forEach(th=>th.onclick=()=>{const k=th.dataset.sort;if(sortKey===k)sortDir*=-1;else{sortKey=k;sortDir=1}apply()});apply();
</script></body></html>
'''


def write_html(path: Path, packs: list[dict], stats: dict) -> None:
    compact = json.dumps([compact_pack(pack) for pack in packs], ensure_ascii=False, separators=(",", ":"))
    compact = compact.replace("</script", "<\\/script")
    output = HTML_TEMPLATE.replace("__PACKS__", compact).replace(
        "__STATS__", json.dumps(stats, ensure_ascii=False, separators=(",", ":"))
    )
    path.write_text(output, encoding="utf-8")


VERIFY_SCRIPT = r'''#!/usr/bin/env python3
"""Verify reconstructed Hoot Archive links without downloading full packs."""
import argparse, concurrent.futures, json, random, urllib.request
from pathlib import Path

def check(pack):
    request=urllib.request.Request(pack["url"],headers={"Range":"bytes=0-3","User-Agent":"Hoot-Archive-Link-Verifier/1.0"})
    try:
        with urllib.request.urlopen(request,timeout=30) as response:
            signature=response.read(4)
            ok=response.status in (200,206) and signature==b"PK\x03\x04"
            return {"archive":pack["archive"],"system":pack["system"],"url":pack["url"],"status":response.status,"zip":ok}
    except Exception as exc:
        return {"archive":pack["archive"],"system":pack["system"],"url":pack["url"],"status":getattr(exc,"code",None),"zip":False,"error":str(exc)}

p=argparse.ArgumentParser()
p.add_argument("--catalog",default="hoot_archive_catalog.json")
g=p.add_mutually_exclusive_group();g.add_argument("--all",action="store_true",help="Check all links; be considerate of the old server")
g.add_argument("--sample",type=int,default=25,help="Deterministic sample size (default: 25)")
p.add_argument("--workers",type=int,default=4)
p.add_argument("--output",default="verification_report.json")
a=p.parse_args()
packs=json.loads(Path(a.catalog).read_text(encoding="utf-8"))["packs"]
if not a.all:
    random.Random(20080905).shuffle(packs);packs=packs[:max(1,min(a.sample,len(packs)))]
with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,min(a.workers,8))) as pool:
    results=list(pool.map(check,packs))
Path(a.output).write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
good=sum(item["zip"] for item in results)
print(f"Verified {good}/{len(results)} ZIP links; report: {a.output}")
'''


def write_readme(path: Path, catalog: dict) -> None:
    stats = catalog["stats"]
    path.write_text(
        f"""# Hoot Archive Recovery Catalog

This bundle reconstructs a static catalog for the Hoot Archive at
`https://snesmusic.org/hoot/v2/`. The dynamic PHP/database pages stopped
rendering, while the official pack storage and metadata downloads remained
available.

## Contents

- `hoot_archive_catalog.html` — standalone searchable browser with original download links.
- `hoot_archive_catalog.json` — complete machine-readable catalog, including contained files and CRC32 values.
- `hoot_archive_catalog.csv` — flat pack-level export.
- `hoot_archive_catalog.sqlite3` — normalized SQLite database (`packs`, `files`, `alternate_titles`, `metadata`).
- `verify_hoot_archive.py` — optional low-impact link verifier.
- `build_hoot_catalog.py` — reproducible catalog generator.

## Catalog summary

- Packs: {stats['pack_count']:,}
- Systems: {stats['system_count']:,}
- XML metadata matches: {stats['metadata_matched']:,}
- Files described by manifests: {stats['file_count']:,}

Arcade ROM entries are intentionally excluded because the Hoot site did not
host those ROM sets. No game music archives are included in this bundle.

## Usage

Open `hoot_archive_catalog.html` in a browser. It does not need a web server.

To verify a considerate sample of 25 original links:

```sh
python3 verify_hoot_archive.py
```

To check a larger sample:

```sh
python3 verify_hoot_archive.py --sample 100
```

Avoid repeatedly checking every link: this is an old community server.

## Sources

- `{DATAFILE_URL}`
- `{INI_URL}`

Generated: {catalog['generated_at']}
""",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("Hoot_Archive_Recovery_Catalog"))
    parser.add_argument("--bundle", type=Path, default=Path("Hoot_Archive_Recovery_Catalog_2026-08-09.zip"))
    args = parser.parse_args()

    data_bytes, data_headers = fetch(DATAFILE_URL)
    ini_bytes, ini_headers = fetch(INI_URL)
    packs, stats = build_catalog(data_bytes, ini_bytes)
    generated_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    catalog = {
        "schema_version": 1,
        "generated_at": generated_at,
        "sources": {
            "datafile": {
                "url": DATAFILE_URL,
                "sha256": hashlib.sha256(data_bytes).hexdigest(),
                "last_modified": data_headers.get("last-modified", ""),
            },
            "ini": {
                "url": INI_URL,
                "sha256": hashlib.sha256(ini_bytes).hexdigest(),
                "last_modified": ini_headers.get("last-modified", ""),
            },
        },
        "stats": stats,
        "packs": packs,
    }

    if args.output.exists():
        shutil.rmtree(args.output)
    args.output.mkdir(parents=True)
    write_json(args.output / "hoot_archive_catalog.json", catalog)
    write_csv(args.output / "hoot_archive_catalog.csv", packs)
    write_sqlite(args.output / "hoot_archive_catalog.sqlite3", catalog)
    write_html(args.output / "hoot_archive_catalog.html", packs, stats)
    (args.output / "verify_hoot_archive.py").write_text(VERIFY_SCRIPT, encoding="utf-8")
    shutil.copy2(Path(__file__), args.output / "build_hoot_catalog.py")
    write_readme(args.output / "README.md", catalog)

    if args.bundle.exists():
        args.bundle.unlink()
    with zipfile.ZipFile(args.bundle, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for file_path in sorted(args.output.iterdir()):
            bundle.write(file_path, arcname=f"{args.output.name}/{file_path.name}")

    print(json.dumps({"bundle": str(args.bundle), "output": str(args.output), "stats": stats}, indent=2))


if __name__ == "__main__":
    main()
